package com.aricent.poc.msinstancesapp.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.aricent.poc.mscommon.CustomException;
import com.aricent.poc.mscommon.spi.IcustomLogger;
import com.aricent.poc.msinstancesapp.controller.AppController;
import com.aricent.poc.msinstancesapp.model.InputModel;
import com.aricent.poc.msinstancesapp.model.ResponseModel;

@Service
public class ServiceDelegater {
    
    @Autowired
    private IcustomLogger logger;
    
    @Autowired
    private CalculationServiceProxy calculationServiceProxy;

    public ResponseModel callService(String operation, String max, String min) throws CustomException {
        logger.serviceEntryLog("In Method: callService ", operation, Level.INFO, AppController.class);
        
        BigDecimal firstvalue=new BigDecimal(max);
        BigDecimal secondvalue=new BigDecimal(min);
        InputModel inputmodel=new InputModel(firstvalue,secondvalue);
        ResponseEntity<ResponseModel> forEntity =null;
        
        if(("SUM").equals(operation.toUpperCase())) {
        forEntity = new RestTemplate().postForEntity("http://localhost:8100/SUM", inputmodel,ResponseModel.class);
        
        }else if(("SUB").equals(operation.toUpperCase())) {
            
         forEntity = new RestTemplate().postForEntity("http://localhost:8100/SUB", inputmodel,ResponseModel.class);    
        }
        else {
            
            throw new CustomException("Not a valid operation");
        }
        logger.serviceExitLog("Method: callService", operation, Level.INFO, AppController.class);
        return forEntity.getBody();
    }

    public ResponseModel callViaFeignService(String operation, String max, String min) throws CustomException {
        logger.serviceEntryLog("In Method: callViaFeignService ", operation, Level.INFO, AppController.class);
        
        BigDecimal firstvalue=new BigDecimal(max);
        BigDecimal secondvalue=new BigDecimal(min);
        InputModel inputmodel=new InputModel(firstvalue,secondvalue);
        ResponseEntity<ResponseModel> forEntity =null;
            if(("SUM").equals(operation.toUpperCase())) {
            forEntity = calculationServiceProxy.getSum(inputmodel);
            
            }else if(("SUB").equals(operation.toUpperCase())) {
                
                forEntity = calculationServiceProxy.getSub(inputmodel);
            }
            else {
                
                throw new CustomException("Not a valid operation");
            }
        logger.serviceExitLog("Method: callViaFeignService", operation, Level.INFO, AppController.class);
        return forEntity.getBody();
    }
    
    
}
