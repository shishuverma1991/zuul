package com.aricent.poc.msinstancesapp.controller.advice;

import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.aricent.poc.mscommon.CommonExceptionStructure;
import com.aricent.poc.mscommon.CustomException;
import com.aricent.poc.mscommon.spi.IcustomLogger;
import com.aricent.poc.msinstancesapp.controller.AppController;
import com.aricent.poc.msinstancesapp.helper.ErrorCode;

@ControllerAdvice
public class AppControllerException extends ResponseEntityExceptionHandler {
	
    @Autowired
    private IcustomLogger logger;
	
	@ExceptionHandler({ CustomException.class, Exception.class })
	public final ResponseEntity<CommonExceptionStructure> handleAppException(Exception exception, WebRequest request)
			throws Exception {
	    logger.controllerEntryLog(exception.getMessage(), null, Level.ERROR, AppController.class);
		CommonExceptionStructure commonExceptionStructure = null;
		if (exception instanceof CustomException) {
			commonExceptionStructure = new CommonExceptionStructure(ErrorCode.Key_Null.getErrorCode(),
					exception.getMessage());
		} else {
			commonExceptionStructure = new CommonExceptionStructure(ErrorCode.Error_Exception.getErrorCode(),
					exception.getMessage());
		}
		logger.controllerExitLog(exception.getMessage(), null, Level.ERROR, AppController.class);
		return new ResponseEntity<CommonExceptionStructure>(commonExceptionStructure, HttpStatus.NOT_FOUND);
	}
}
