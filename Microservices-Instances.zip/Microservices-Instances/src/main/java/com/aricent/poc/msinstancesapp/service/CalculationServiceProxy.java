package com.aricent.poc.msinstancesapp.service;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.aricent.poc.msinstancesapp.model.InputModel;
import com.aricent.poc.msinstancesapp.model.ResponseModel;

//@FeignClient(name="Calculation-Microservice",url="localhost:8100")-----uncomment it if u r not using zuul gateway
//@FeignClient(name="Calculation-Microservice")
@FeignClient(name="Zuul-Gateway-Server")
@RibbonClient(name="Calculation-Microservice")
public interface CalculationServiceProxy  {
    
    //@PostMapping(value = "/SUM", produces = MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
    
    @PostMapping(value = "/calculation-microservice/SUM", produces = MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseModel> getSum(@RequestBody InputModel inputModel);

    //@PostMapping(value = "/SUB", produces = MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
    
    @PostMapping(value = "/calculation-microservice/SUB", produces = MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseModel> getSub(@RequestBody InputModel inputmodel);
}
