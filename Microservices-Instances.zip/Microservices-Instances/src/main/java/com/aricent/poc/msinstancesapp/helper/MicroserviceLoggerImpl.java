package com.aricent.poc.msinstancesapp.helper;

import org.springframework.stereotype.Component;

import com.aricent.poc.mscommon.CustomLogger;

@Component
public class MicroserviceLoggerImpl extends CustomLogger {

    public MicroserviceLoggerImpl() {
        super();
    }
    
    
}
