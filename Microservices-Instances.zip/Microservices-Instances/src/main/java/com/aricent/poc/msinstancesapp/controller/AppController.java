package com.aricent.poc.msinstancesapp.controller;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.aricent.poc.mscommon.CustomException;
import com.aricent.poc.mscommon.spi.IcustomLogger;
import com.aricent.poc.msinstancesapp.Configuration.ConfigurationManager;
import com.aricent.poc.msinstancesapp.model.ResponseModel;
import com.aricent.poc.msinstancesapp.service.ServiceDelegater;

//@RefreshScope
@RestController
public class AppController {
	
	@Autowired
	private ConfigurationManager configurationManager;
	
	@Autowired
	private IcustomLogger logger;
	
	@Autowired
	private ServiceDelegater serviceDelegater;
	
	
	@GetMapping(value="/limits/{value}", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseModel> getInstanceLimits(@PathVariable(name="value",required=true)String value) throws CustomException {
		logger.controllerEntryLog(null, value, Level.INFO, AppController.class);
		String configuration = configurationManager.getConfiguration(value);
		if(configuration==null) {
			throw new CustomException("Key that you passed in request is not defined");
		}
		logger.controllerExitLog(null, value, Level.INFO, AppController.class);
		
		
		List<Link> linkList=prepareLinkList();
		
		ResponseModel responseModel=new ResponseModel("Limit For "+value, new BigDecimal(configuration), "find Limit");
		responseModel.add(linkList);
		
		return new ResponseEntity<ResponseModel>(responseModel,HttpStatus.ACCEPTED);
	}
	
	
	private List<Link> prepareLinkList() throws CustomException {
	    List<Link> linkList=new ArrayList<Link>();
        linkList.add(linkTo(methodOn(AppController.class).getInstanceLimits("maximum")).withRel("Limit maximum"));
        linkList.add(linkTo(methodOn(AppController.class).getInstanceLimits("minimum")).withRel("Limit maximum"));
        linkList.add(linkTo(methodOn(AppController.class).performOperation("SUM")).withRel("Perform Direct SUM"));
        linkList.add(linkTo(methodOn(AppController.class).performOperation("SUB")).withRel("Perform Direct SUB"));
        linkList.add(linkTo(methodOn(AppController.class).feignperformOperation("SUM")).withRel("Perform Feign SUM"));
        linkList.add(linkTo(methodOn(AppController.class).feignperformOperation("SUB")).withRel("Perform Feign SUB"));
        return linkList;
        
    }


    @GetMapping(value="/testService/{operation}", produces=MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseModel> performOperation(@PathVariable(name="operation",required=true)String operation) throws CustomException {
        logger.controllerEntryLog(null, operation, Level.INFO, AppController.class);
       
        String max = configurationManager.getConfiguration("maximum");
        String min = configurationManager.getConfiguration("minimum");
        ResponseModel response=serviceDelegater.callService(operation,max,min);
        response.setProfilevalues("Profile has max & min value as :"+ max+" & "+min);
        
        List<Link> linkList=prepareLinkList();
        response.add(linkList);
        
        logger.controllerExitLog(null, operation, Level.INFO, AppController.class);
        return new ResponseEntity<ResponseModel>(response,HttpStatus.ACCEPTED);
    }
	
	
	@GetMapping(value="/testFeignService/{operation}", produces=MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseModel> feignperformOperation(@PathVariable(name="operation",required=true)String operation) throws CustomException {
        logger.controllerEntryLog(null, operation, Level.INFO, AppController.class);
       
        String max = configurationManager.getConfiguration("maximum");
        String min = configurationManager.getConfiguration("minimum");
        ResponseModel response=serviceDelegater.callViaFeignService(operation,max,min);
        response.setProfilevalues("Profile has max & min value as :"+ max+" & "+min);
        List<Link> linkList=prepareLinkList();
        response.add(linkList);
        logger.controllerExitLog(null, operation, Level.INFO, AppController.class);
        return new ResponseEntity<ResponseModel>(response,HttpStatus.ACCEPTED);
    }
	
}
