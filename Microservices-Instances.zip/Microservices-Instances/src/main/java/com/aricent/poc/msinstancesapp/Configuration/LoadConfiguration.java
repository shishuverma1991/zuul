package com.aricent.poc.msinstancesapp.Configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import brave.sampler.Sampler;

@Configuration
public class LoadConfiguration {
    
    @Bean
    public Sampler getSampler() {
        
        return Sampler.ALWAYS_SAMPLE;
    }
}
