package com.aricent.poc.msinstancesapp.model;
import java.math.BigDecimal;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;

import org.springframework.stereotype.Component;

@Component
public class InputModel {
    
    @NotEmpty
    @Digits(integer=6, fraction=2, message="{javax.validation.constraints.Digits.message}")
    private BigDecimal firstValue;
    
    
    @NotEmpty
    @Digits(integer=6, fraction=2, message="{javax.validation.constraints.Digits.message}")
    private BigDecimal secondValue;
    
    public InputModel() {
        // TODO Auto-generated constructor stub
    }
    
   
    public InputModel(BigDecimal firstvalue, BigDecimal secondvalue) {
        this.firstValue=firstvalue;
        this.secondValue=secondvalue;
    }


    public BigDecimal getFirstValue() {
        return firstValue;
    }
    public void setFirstValue(BigDecimal firstValue) {
        this.firstValue = firstValue;
    }
    public BigDecimal getSecondValue() {
        return secondValue;
    }
    public void setSecondValue(BigDecimal secondValue) {
        this.secondValue = secondValue;
    }
    
    
}
