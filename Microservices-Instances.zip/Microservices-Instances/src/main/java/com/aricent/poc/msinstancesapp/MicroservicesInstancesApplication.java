package com.aricent.poc.msinstancesapp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients("com.aricent.poc.msinstancesapp.service")
@EnableEurekaClient
public class MicroservicesInstancesApplication {
    
    
    
	private final static Logger logger = LoggerFactory.getLogger(MicroservicesInstancesApplication.class);
	public static void main(String[] args) {
		logger.info("Spring Boot is starting Microservices-Instances Application!");
		SpringApplication.run(MicroservicesInstancesApplication.class, args);
		logger.info("Spring Boot has started Microservices-Instances Application succesfully!");
	}
}
