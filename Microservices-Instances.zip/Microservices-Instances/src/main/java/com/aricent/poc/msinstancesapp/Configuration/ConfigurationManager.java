package com.aricent.poc.msinstancesapp.Configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.aricent.poc.mscommon.spi.CommonManager;
import com.aricent.poc.mscommon.spi.IcustomLogger;
import com.aricent.poc.msinstancesapp.controller.AppController;


@Component
public class ConfigurationManager implements CommonManager {

	@Autowired
	private Environment environment;
	
	@Autowired
    private IcustomLogger logger;
	
	
	@Override
	public String getConfiguration(String key) {
		
		logger.serviceEntryLog(null, key, Level.INFO, ConfigurationManager.class);
		String value=null;
		switch(key) {
		case "minimum":
			value=environment.getProperty("msinstance.minimum");
			break;
		case "maximum":	
			value=environment.getProperty("msinstance.maximum");
			break;
		default:
			break;
		}
		logger.serviceExitLog(null, key, Level.INFO, ConfigurationManager.class);
		return value;
	}
	
}
