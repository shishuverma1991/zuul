package com.aricent.poc.zuulserver.filters;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aricent.poc.mscommon.spi.IcustomLogger;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

@Component
public class CustomZuulFilter extends ZuulFilter{

    
    @Autowired
    private IcustomLogger logger;
    
    
    @Override
    public Object run() throws ZuulException {
        HttpServletRequest request = RequestContext.getCurrentContext().getRequest();
        logger.controllerEntryLog("Filter at Proxy Server.....", request.getRequestURI(), Level.INFO, CustomZuulFilter.class);
        return null;
    }

    @Override
    public boolean shouldFilter() {
        // TODO Auto-generated method stub
        return true;
    }

    @Override
    public int filterOrder() {
        // TODO Auto-generated method stub
        return 1;
    }

    @Override
    public String filterType() {
        // TODO Auto-generated method stub
        return "pre";
    }
}
